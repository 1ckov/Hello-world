package pr1.uebung03;

import static pr.MakeItSimple.*;

public class DividersArray {

	public static void main(String[] args) {
		int zahl;
		int summe;
		int[] dividers = new int[35];
		println("Bitte eine x-beliebige ganze Zahl eingeben: ");
		zahl = readInt();
		int zehler = zahl;
		int position = 0;
		if(zahl>0){
			while (zehler > 0) {
				summe = zahl % zehler;
				if (summe == 0){
					dividers[position]=zehler;
					position++;
				}
				zehler--;
			}
		}
		else if (zahl <= 0) {
			println("Eingabe ungültig");
		}
		int i = 0;
		while (position > i){
			print(dividers[i]+" ");
			i++;
		}
	}

}
