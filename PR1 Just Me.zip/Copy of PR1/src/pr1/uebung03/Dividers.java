package pr1.uebung03;

import static pr.MakeItSimple.*;

public class Dividers {

	public static void main(String[] args) {
		int zahl;
		println("Bitte eine x-beliebige ganze Zahl eingeben: ");
		zahl = readInt();
		int summe;
		int zehler = zahl;
		if (zahl > 0) {
			while (zehler > 0) {
				summe = zahl % zehler;
				if (summe == 0) {
					print(zehler + " ");
				}
				zehler--;
			}
		}
		else if (zahl <= 0) {
			println("Eingabe ungültig");
		}
	}
}
