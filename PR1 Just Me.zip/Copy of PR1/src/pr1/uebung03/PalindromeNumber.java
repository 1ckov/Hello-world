package pr1.uebung03;

import static pr.MakeItSimple.*;

public class PalindromeNumber {

	public static void main(String[] args) {
		int counter = 0;
		while(counter == 0){
			System.out.println("for exit write smth or continue 0");
			counter = readInt();
			int yourNumber = 0; 
			println("geben sie eine x-belibige zahl an: ");
			yourNumber = readInt();
			int[] numberStorage = new int[10];
			int i=0;

			if(yourNumber > 0 && yourNumber <2000000000){
				while (yourNumber > 0 ){
					numberStorage[i]=yourNumber%10;
					yourNumber=yourNumber/10;
					i++;
				}

				int j=0;

				while(i>=1 && i!=j && i-1>j){
					if(numberStorage[i-1]==numberStorage[j]){
						i--;
						j++;
					}
					else{
						println("Die eingegebene Zahl ist kein Palindrom");
						break;
					}
				}
				if(i-1<j || i-1==j){
					println("Die eingegebene Zahl ist ein Palindrom");
				}
			}
			else
				println("Ungültige Eingabe");
		}
		}
		
}



