package pr1.uebung01;

import static pr.MakeItSimple.*;

public class MyOwnHelloWorld {
	
	public static void main(String[] args) {
	
		println("Hello Friend , what's your Name? ");
		String firstName;
		firstName = readString();
		println("Nice to meet you " + firstName + ".");
		
	}

}